(function(w) {
    function enterLine() {
        let enterUrl = 'http://caiziav.xyz';
        document.getElementById("btnEnter").onclick = function() {
            window.open(enterUrl, "_blank");
        }
    }
    function init() {
        enterLine();
    }
    window.addEventListener("DOMContentLoaded", init, !1);
})(window);

(function(w) {
    function enterLine() {
        let enterUrl = 'http://caiziav.github.io';
        document.getElementById("btnfabu").onclick = function() {
            window.open(enterUrl, "_blank");
        }
    }
    function init() {
        enterLine();
    }
    window.addEventListener("DOMContentLoaded", init, !2);
})(window);
